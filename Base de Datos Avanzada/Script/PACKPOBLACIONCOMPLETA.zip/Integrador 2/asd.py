import pandas as pd

# Leer el archivo 202012_multibdd_personas (3).csv, incluyendo todas las columnas
df_personas = pd.read_csv('202012_multibdd_personas (3).csv', delimiter=';', low_memory=False)

# Leer el archivo complementarios.csv, incluyendo todas las columnas y estableciendo dtype para la columna "id_hogar"
df_complementarios = pd.read_csv('enemdu_vivienda_hogar_2023_I_trimestre.csv', delimiter=';', dtype={'id_hogar': str}, low_memory=False)

# Convertir la columna "id_hogar" de df_personas 
df_personas['id_hogar'] = df_complementarios['id_hogar']

# Actualizar la columna "id_hogar" en df_complementarios con los valores de df_personas
df_personas['id_hogar'] = df_complementarios['id_hogar']

# Guardar los cambios en el archivo CSV complementarios.csv con los valores actualizados
df_personas.to_csv('complementarios.csv', sep=';', index=False)
