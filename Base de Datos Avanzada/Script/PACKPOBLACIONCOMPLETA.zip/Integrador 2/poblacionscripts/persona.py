import mysql.connector
import pandas as pd

# Datos de conexión a la base de datos
db_config = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': '12345678',
    'database': 'mydb'  # Nombre de la base de datos
}

# Crea una conexión a la base de datos
cnx = mysql.connector.connect(**db_config)
cursor = cnx.cursor()

# Cargamos los datos del archivo csv en un dataframe de pandas
df = pd.read_csv('complementarios.csv', delimiter=';')

# Eliminar registros con 'NULL' en el campo 'id_hogar'
df = df[df['id_hogar'] != 'NULL']

# Iteramos sobre cada fila del dataframe
for index, row in df.iterrows():
    # Verificamos si hay valores None o espacios vacíos en las columnas
    for column in df.columns:
        if pd.isna(row[column]) or str(row[column]).strip() == "":
            # Si hay valor None o espacio vacío, lo reemplazamos con la palabra 'NULL'
            row[column] = 'NULL'
    
    # Preparamos la sentencia SQL para insertar los datos en la tabla 'Persona'
    query_persona = f"""
    INSERT INTO Persona (idPersona, s1p2, s1p3, s1p7, s1p8, s1p12a, s1p13, id_hogar)
    VALUES ({row['id_per']}, {row['s1p2']}, {row['s1p3']}, {row['s1p7']}, {row['s1p8']},
    {row['s1p12a']}, {row['s1p13']}, {row['id_hogar']})
    """
    
    try:
        # Ejecutamos la sentencia SQL
        cursor.execute(query_persona)
        # Hacemos commit para que los cambios se guarden en la base de datos
        cnx.commit()
    except mysql.connector.Error as error:
        # Manejo de la excepción por error de integridad referencial
        print(f"Error al insertar persona: {error}")
        print(f"Consulta que falló: {query_persona}")
        # Si ocurre un error, omitimos esta fila y pasamos a la siguiente
        continue

# Cierra la conexión
cursor.close()
cnx.close()
